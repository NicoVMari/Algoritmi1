/* vim: set tabstop=4 expandtab shiftwidth=4 softtabstop=4: */

/*
 * Copyright 2015 University of Piemonte Orientale, Computer Science Institute
 *
 * This file is part of UPOalglib.
 *
 * UPOalglib is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * UPOalglib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with UPOalglib.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "bst_private.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>


/**** EXERCISE #1 - BEGIN of FUNDAMENTAL OPERATIONS ****/
int upo_bts_isLeaf_imp(upo_bst_node_t *node);

upo_bst_t upo_bst_create(upo_bst_comparator_t key_cmp)
{
    upo_bst_t tree = malloc(sizeof(struct upo_bst_s));
    if (tree == NULL)
    {
        perror("Unable to create a binary search tree");
        abort();
    }

    tree->root = NULL;
    tree->key_cmp = key_cmp;

    return tree;
}

void upo_bst_destroy(upo_bst_t tree, int destroy_data)
{
    if (tree != NULL)
    {
        upo_bst_clear(tree, destroy_data);
        free(tree);
    }
}

void upo_bst_clear_imp(upo_bst_node_t *node, int destroy_data)
{
    if (node != NULL)
    {
        upo_bst_clear_imp(node->left, destroy_data);
        upo_bst_clear_imp(node->right, destroy_data);

        if (destroy_data)
        {
            free(node->key);
            free(node->value);
        }

        free(node);
    }
}

void upo_bst_clear(upo_bst_t tree, int destroy_data)
{
    if (tree != NULL)
    {
        upo_bst_clear_imp(tree->root, destroy_data);
        tree->root = NULL;
    }
}

upo_bst_node_t* upo_bst_put_imp(upo_bst_node_t *node, void *key, void *value,void **v_old,upo_bst_comparator_t key_cmp)
{
  *v_old = NULL;
  if (node == NULL) {
    upo_bst_node_t *new_node = malloc(sizeof(struct upo_bst_node_s));
    if (new_node == NULL){
        perror("Unable to create a new node for binary search tree");
        exit(1);
    }else{
      new_node->key = key;
      new_node->value = value;
      new_node->left = NULL;
      new_node->right = NULL;
      node = new_node;
      return node;
    }
  }else{
    int cmp = key_cmp(key, node->key);
    if (cmp < 0){
        node->left = upo_bst_put_imp(node->left, key, value, v_old, key_cmp);
    }else if (cmp > 0){
        node->right = upo_bst_put_imp(node->right, key, value, v_old, key_cmp);
    }else{
        *v_old = node->value;
        node->value = value;
    }

    return node;
  }
}

void* upo_bst_put(upo_bst_t tree, void *key, void *value){
    if(tree == NULL || key == NULL || value == NULL) return NULL;

    void *v_old = NULL;
    tree->root = upo_bst_put_imp(tree->root,key,value,&v_old,tree->key_cmp);
    return v_old;
}

upo_bst_node_t* upo_bst_insert_imp(upo_bst_node_t *node, void *key, void *value,upo_bst_comparator_t key_cmp){
  if (node == NULL) {
    upo_bst_node_t *new_node = malloc(sizeof(struct upo_bst_node_s));
    if (new_node == NULL){
        perror("Unable to create a new node for binary search tree");
        abort();
    }else{
      new_node->key = key;
      new_node->value = value;
      new_node->left = NULL;
      new_node->right = NULL;
      node = new_node;
    }
  }

  int cmp = key_cmp(key, node->key);
  if (cmp < 0) {
    node->left = upo_bst_insert_imp(node->left,key,value,key_cmp);
  }else if (cmp>0) {
    node->right = upo_bst_insert_imp(node->right,key,value,key_cmp);
  }

  return node;
}

void upo_bst_insert(upo_bst_t tree, void *key, void *value)
{
    if(tree != NULL) tree->root = upo_bst_insert_imp(tree->root,key,value,tree->key_cmp);
}

upo_bst_node_t* upo_bst_get_imp( upo_bst_node_t *node,const void *key,upo_bst_comparator_t key_cmp){
  if(node == NULL)return NULL;

  int cmp = key_cmp(key, node->key);
  if(cmp < 0)return upo_bst_get_imp(node->left,key,key_cmp);
  else if(cmp > 0) return upo_bst_get_imp(node->right,key,key_cmp);
  else return node;

}

void* upo_bst_get(const upo_bst_t tree, const void *key)
{
  if(tree == NULL || tree->root == NULL) return NULL;

  upo_bst_node_t *new_node = upo_bst_get_imp(tree->root,key,tree->key_cmp);
  if(tree->root != NULL) return new_node->value;
  else return NULL;
}

int upo_bst_contains(const upo_bst_t tree, const void *key)
{
    if(tree == NULL || key == NULL) return 0;

    if(upo_bst_get_imp(tree->root,key,tree->key_cmp) != NULL)return 1;
    else return 0;
}

upo_bst_node_t *upo_bts_min_imp(upo_bst_node_t *node){
  if(node == NULL) return NULL;
  else if(node->left != NULL) return upo_bts_min_imp(node->left);
  else return node;
}

upo_bst_node_t* upo_bst_delete_imp(upo_bst_node_t *node,const void *key,int destroy_data,upo_bst_comparator_t key_cmp){
  if(node == NULL) return NULL;

  int cmp=key_cmp(key,node->key);
  if (cmp < 0) node->left = upo_bst_delete_imp(node->left,key,destroy_data,key_cmp);
  else if(cmp > 0) node->right = upo_bst_delete_imp(node->right,key,destroy_data,key_cmp);
  else if(node->left != NULL && node->right != NULL){
    upo_bst_node_t *m = upo_bts_min_imp(node->right);
    if (destroy_data)
    {
        free(node->key);
        free(node->value);
    }
    node->key = m->key;
    node->value = m->value;
    node->right = upo_bst_delete_imp(node->right,node->key,0,key_cmp);
  }
  else{
    upo_bst_node_t *x = node;

    if (node->left != NULL) node = node->left;
    else node = node->right;

    if (destroy_data)
    {
        free(x->key);
        free(x->value);
    }
    free(x);
  }

  return node;
}

void upo_bst_delete(upo_bst_t tree, const void *key, int destroy_data){
  if(tree != NULL){
      tree->root = upo_bst_delete_imp(tree->root,key,destroy_data,tree->key_cmp);
  }
}

size_t upo_bst_size_imp(upo_bst_node_t *node){
  if(node == NULL) return 0;
  return 1 + upo_bst_size_imp(node->left) + upo_bst_size_imp(node->right);
}

size_t upo_bst_size(const upo_bst_t tree)
{
    if(tree == NULL) return 0;
    return upo_bst_size_imp(tree->root);
}

size_t upo_bst_height_imp(upo_bst_node_t *node){
  if(node == NULL || upo_bts_isLeaf_imp(node)) return 0;
  int height_sx = upo_bst_height_imp(node->left);
  int height_dx = upo_bst_height_imp(node->right);
  return 1 + (height_sx > height_dx ? height_sx : height_dx);
}

int upo_bts_isLeaf_imp(upo_bst_node_t *node){
  if(node->left == NULL && node->right == NULL) return 1;
  return 0;
}

size_t upo_bst_height(const upo_bst_t tree)
{
    return upo_bst_height_imp(tree->root);
}

void upo_bst_traverse_in_order_imp(upo_bst_node_t *node,upo_bst_visitor_t visit, void *visit_context){
    if(node != NULL){
      upo_bst_traverse_in_order_imp(node->left,visit,visit_context);
      visit(node->key, node->value, visit_context);
      upo_bst_traverse_in_order_imp(node->right,visit,visit_context);
    }
}

void upo_bst_traverse_in_order(const upo_bst_t tree, upo_bst_visitor_t visit, void *visit_context){
  if(tree == NULL ) return;
  upo_bst_traverse_in_order_imp(tree->root,visit,visit_context);
}

int upo_bst_is_empty(const upo_bst_t tree){
  if (tree == NULL || tree->root == NULL)return 1;
  else return 0;
}


/**** EXERCISE #1 - END of FUNDAMENTAL OPERATIONS ****/


/**** EXERCISE #2 - BEGIN of EXTRA OPERATIONS ****/


void* upo_bst_min(const upo_bst_t tree)
{
    if (tree != NULL && tree->root != NULL) {
        upo_bst_node_t *temp = tree->root;
        while(temp->left != NULL){
            temp = temp->left;
        }
        return temp->key;
    }

    return NULL;
}

void* upo_bst_max(const upo_bst_t tree)
{
  if (tree != NULL && tree->root != NULL) {
      upo_bst_node_t *temp = tree->root;
      while(temp->right != NULL)
        temp = temp->right;
      return temp->key;
  }
  else return NULL;
}

void upo_bst_delete_min(upo_bst_t tree, int destroy_data)
{
  if (tree != NULL && tree->root != NULL) {
      tree->root = upo_bst_delete_imp(tree->root,upo_bst_min(tree),destroy_data,tree->key_cmp);
  }
}

void upo_bst_delete_max(upo_bst_t tree, int destroy_data)
{
  if (tree != NULL && tree->root != NULL) {
      tree->root = upo_bst_delete_imp(tree->root,upo_bst_max(tree),destroy_data,tree->key_cmp);
  }
}

const upo_bst_node_t *upo_bst_floor_imp(const upo_bst_node_t* node,const void* key, upo_bst_comparator_t key_cmp){
  if(node != NULL){
    int cmp = key_cmp(key,node->key);
    if(cmp <0) return upo_bst_floor_imp(node->left,key,key_cmp);
    else if(cmp>0){
      const upo_bst_node_t* floor_node= NULL;
      floor_node = upo_bst_floor_imp(node->right,key,key_cmp);
      return (floor_node != NULL) ? floor_node : node;
    }else return node;
  }
  return NULL;
}

void* upo_bst_floor(const upo_bst_t tree, const void *key)
{
    if (tree != NULL) {
      const upo_bst_node_t *node = NULL;

      node = upo_bst_floor_imp(tree->root,key,tree->key_cmp);
      if(node != NULL) return node->key;
    }
    return NULL;
}

const void *upo_bst_ceiling_imp(const upo_bst_node_t *node,const void *key,upo_bst_comparator_t key_cmp){
  if(node != NULL){
    int cmp = key_cmp(node->key,key);
    if (cmp < 0) {
      return upo_bst_ceiling_imp(node->right,key,key_cmp);
    }else{
      const void *left_ceiling = upo_bst_ceiling_imp(node->left,key,key_cmp);
      if(left_ceiling) return left_ceiling;
      else return node;
    }
  }
  return NULL;
}

void* upo_bst_ceiling(const upo_bst_t tree, const void *key)
{
  if(tree != NULL){
    const upo_bst_node_t *node = NULL;

    node = upo_bst_ceiling_imp(tree->root,key,tree->key_cmp);
    if(node != NULL) return node->key;
  }
  return NULL;
}

void upo_bst_keys_range_imp(const upo_bst_node_t* node, const void *low_key, const void *high_key, upo_bst_key_list_t *list,upo_bst_comparator_t key_cmp){
  if(node != NULL){
    upo_bst_keys_range_imp(node->left,low_key,high_key,list,key_cmp);

    if(key_cmp(node->key,low_key)>=0 && key_cmp(node->key,high_key)<=0){
        upo_bst_key_list_node_t* new_node = malloc(sizeof(struct upo_bst_key_list_node_s));
        new_node->key = node->key;
        new_node->next = *list;
        *list = new_node;
    }

    upo_bst_keys_range_imp(node->right,low_key,high_key,list,key_cmp);
  }
}

upo_bst_key_list_t upo_bst_keys_range(const upo_bst_t tree, const void *low_key, const void *high_key)
{
  if(tree != NULL){
    upo_bst_key_list_t list = NULL;

    upo_bst_keys_range_imp(tree->root, low_key, high_key, &list,tree->key_cmp);

    return list;
  }

  return NULL;
}

void upo_bst_keys_impl(const upo_bst_node_t *node, upo_bst_comparator_t key_cmp, upo_bst_key_list_t *list){
  if (node != NULL){
  upo_bst_keys_impl(node->left, key_cmp, list);
  upo_bst_key_list_node_t *list_node = NULL;
  list_node = malloc(sizeof(struct upo_bst_key_list_node_s));
  if (list_node == NULL)
  {
    perror("Unable to allocate memory for a new node of the key list");
    abort();
  }
  list_node->key = node->key;
  list_node->next = *list;
  *list = list_node;

  upo_bst_keys_impl(node->right, key_cmp, list);
  }
}


upo_bst_key_list_t upo_bst_keys(const upo_bst_t tree)
{
  if (tree != NULL)
  {
    upo_bst_key_list_t list = NULL;
    upo_bst_keys_impl(tree->root, tree->key_cmp, &list);
    return list;
  }
  return NULL;
}

int upo_bst_is_bst_impl(const upo_bst_node_t *node, const void *min_key, int min_key_changed, const void *max_key, int max_key_changed, upo_bst_comparator_t key_cmp){
  if(node == NULL) return 1;

  if(key_cmp(node->key,min_key) < 0 || (min_key_changed && key_cmp(node->key, min_key) == 0) || key_cmp(node->key, max_key) > 0 || (max_key_changed && key_cmp(node->key, max_key) == 0)) return 0;

  return upo_bst_is_bst_impl(node->left, min_key, min_key_changed, node->key, 1,key_cmp) && upo_bst_is_bst_impl(node->right, node->key, 1, max_key, max_key_changed,key_cmp);
}

int upo_bst_is_bst(const upo_bst_t tree, const void *min_key, const void *max_key)
{
  if (upo_bst_is_empty(tree)) return 1;
  return upo_bst_is_bst_impl(tree->root, min_key, 0, max_key, 0, tree->key_cmp);
}


/**** EXERCISE #2 - END of EXTRA OPERATIONS ****/


upo_bst_comparator_t upo_bst_get_comparator(const upo_bst_t tree)
{
    if (tree == NULL)
    {
        return NULL;
    }

    return tree->key_cmp;
}
